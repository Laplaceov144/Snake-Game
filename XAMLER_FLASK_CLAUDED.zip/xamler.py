import requests
import base64
import re
import xml.etree.ElementTree as ET
import html
from xml.sax.saxutils import escape
from SETTINGS import ENDPOINTS, PROXIES, CONFIG_REPORT_PATH, CONFIG_ENV
requests.packages.urllib3.disable_warnings()

# Jeden wyjątek dla różnych kodów odpowiedzi innych niż 200, 201 itp.
class UnexpectedReponse(Exception):
    def __init__(self, status_code, response_body):
        self.status_code = status_code
        self.response_body = response_body
        super().__init__(f"HTTP {status_code}: {response_body}")

def decode_response(code):
    mapping = {
        "401": "błąd autoryzacji",
        "403": "niedozwolone żądanie",
        "500": "wewnętrzny błąd serwera"
    }
    return mapping.get(str(code), "nieoczekiwaną odpowiedź serwera")

def adjust_date_format(date):
    split_date = date.split('-')
    if len(split_date[0]) == 4:
        return f"{split_date[2]}-{split_date[1]}-{split_date[0]}"
    else:
        return date


def endpoint_for_env(env_name):
    # Splitujemy spacją, bo w referencji środowiska możemy mieć dodatkowo odniesienie do konkretnego raportu
    return ENDPOINTS[env_name.split(' ')[0]]


def _local_name(tag):
    # "{namespace}NAME" -> "NAME"
    return tag.rsplit('}', 1)[-1]


def _call_bip(endpoint, report_path, username, password, params=None):
    """Wywołuje runReport w BIP i zwraca zdekodowany tekst XML z danymi raportu."""

    params_xml = ""
    if params:
        items = "".join(
            f"""
                        <pub:item>
                            <pub:name>{escape(name)}</pub:name>
                            <pub:values>
                                <pub:item>{escape(value)}</pub:item>
                            </pub:values>
                        </pub:item>
            """
            for name, value in params.items()
        )
        params_xml = f"""
                    <pub:parameterNameValues>
                    <pub:listOfParamNameValues>
                    {items}
                    </pub:listOfParamNameValues>
                    </pub:parameterNameValues>
        """

    soap_body = f"""
        <soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/"
                        xmlns:pub="http://xmlns.oracle.com/oxp/service/v2">
            <soapenv:Header/>
            <soapenv:Body>
                <pub:runReport>
                <pub:reportRequest>
                    <pub:reportAbsolutePath>{escape(report_path)}</pub:reportAbsolutePath>
                    <pub:sizeOfDataChunkDownload>-1</pub:sizeOfDataChunkDownload>
                    {params_xml}
                    <pub:attributeFormat>xml</pub:attributeFormat>
                </pub:reportRequest>
                
                <pub:userID>{escape(username)}</pub:userID>
                <pub:password>{escape(password)}</pub:password>
                </pub:runReport>

            </soapenv:Body>
        </soapenv:Envelope>
        
        """

    headers = {
        "Content-Type": "text/xml;charset=utf-8",
        "SOAPAction": "runReport",
        "Accept": "text/xml"
    }

    response = requests.post(
        endpoint,
        data=soap_body.encode("utf-8"),
        headers=headers,
        proxies=PROXIES,
        verify=False,       
        timeout=60
    )
    print("HTTP:", response.status_code)

    # BIP przy błędnym loginie/haśle zwraca zwykle SOAP Fault z kodem 500
    if response.status_code != 200:
        raise UnexpectedReponse(response.status_code, response.text[:500])

    root = ET.fromstring(response.content)

    report_bytes_el = None
    for el in root.iter():
        if el.tag.endswith("reportBytes"):
            report_bytes_el = el
            break

    if report_bytes_el is None or not (report_bytes_el.text or "").strip():
        raise UnexpectedReponse(response.status_code, "Brak reportBytes w odpowiedzi BIP")

    b64_data = re.sub(r"\s+", "", report_bytes_el.text)

    # 1) Base64 -> bytes
    b = base64.b64decode(b64_data)

    # 2) Rozpoznaj kodowanie z prologu XML, np. <?xml version="1.0" encoding="UTF-8"?>
    m = re.search(br'<\?xml[^>]*encoding=["\']([^"\']+)["\']', b)
    encoding = m.group(1).decode() if m else "utf-8"

    # 3) bytes -> str
    return b.decode(encoding, errors="replace"), encoding


def fetch_report_catalog(USERNAME, PASSWORD):
    """
    Pobiera z raportu konfiguracyjnego listę dostępnych źródeł danych.
    Przy okazji weryfikuje dane logowania użytkownika (błędne -> UnexpectedReponse).

    Zwraca listę słowników: [{"name": ..., "env_name": ..., "report_path": ...}, ...]
    """
    text, _ = _call_bip(ENDPOINTS[CONFIG_ENV], CONFIG_REPORT_PATH, USERNAME, PASSWORD)

    # Zabezpieczenie przed prologiem z innym kodowaniem niż str (ET nie lubi deklaracji encoding w str)
    text = re.sub(r'^\s*<\?xml[^>]*\?>', '', text)
    root = ET.fromstring(text)

    catalog = []
    seen = set()
    for el in root.iter():
        fields = {_local_name(child.tag).upper(): (child.text or "").strip() for child in el}
        if not {"NAME", "ENV_NAME", "REPORT_PATH"} <= fields.keys():
            continue

        env_name = fields["ENV_NAME"]
        if not env_name or not fields["REPORT_PATH"] or env_name in seen:
            continue
        if env_name.split(' ')[0] not in ENDPOINTS:
            print(f"Pomijam '{env_name}' - brak endpointu w SETTINGS.ENDPOINTS")
            continue

        seen.add(env_name)
        catalog.append({
            "name": fields["NAME"] or env_name,
            "env_name": env_name,
            "report_path": fields["REPORT_PATH"],
        })

    return catalog


def run_report(ENV, REPORT_PATH, USERNAME, PASSWORD, DATE_FROM, DATE_TO):

    DATE_FROM = adjust_date_format(DATE_FROM)
    DATE_TO = adjust_date_format(DATE_TO)

    text, encoding = _call_bip(
        endpoint_for_env(ENV),
        REPORT_PATH,
        USERNAME,
        PASSWORD,
        params={"DATE_FROM": DATE_FROM, "DATE_TO": DATE_TO}
    )

    # 4) Od-escapuj encje
    text_unescaped = html.unescape(text)

    with open('tmp_clean_text.xml', "w", encoding=encoding, newline="") as f:
        f.write(text_unescaped)
    
    return text_unescaped
