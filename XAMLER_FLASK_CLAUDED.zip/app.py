from flask import Flask, render_template, request, send_file, session, redirect, url_for
from datetime import datetime, timedelta
from functools import wraps
import io
import os
import secrets
import threading

from oracle.xamler import run_report, fetch_report_catalog, UnexpectedReponse, decode_response
from oracle.parser import process_xml
from SETTINGS import SESSION_IDLE_MINUTES


app = Flask(__name__)
# Klucz do podpisywania ciasteczka sesji. Najlepiej ustawić stały przez zmienną środowiskową;
# losowy oznacza, że po restarcie aplikacji wszyscy muszą się zalogować ponownie.
app.secret_key = os.environ.get("XAMLER_SECRET_KEY") or secrets.token_hex(32)

SECTIONS = [
    "General",
    "Address",
    "Job",
    "Phone",
    "Email",
    "Person Identifiers",
    "Salary",
    "AssignmentData"
]

# Dane zalogowanych użytkowników trzymamy po stronie serwera (w pamięci),
# a w ciasteczku sesji jest tylko losowy identyfikator - hasło nie trafia do przeglądarki.
_USER_STORE = {}
_STORE_LOCK = threading.Lock()
_IDLE_TIMEOUT = timedelta(minutes=SESSION_IDLE_MINUTES)


def _purge_expired():
    now = datetime.now()
    with _STORE_LOCK:
        for sid in [s for s, d in _USER_STORE.items() if now - d["last_seen"] > _IDLE_TIMEOUT]:
            del _USER_STORE[sid]


def current_user():
    _purge_expired()
    sid = session.get("sid")
    if not sid:
        return None
    with _STORE_LOCK:
        data = _USER_STORE.get(sid)
        if data:
            data["last_seen"] = datetime.now()
        return data


def login_required(view):
    @wraps(view)
    def wrapper(*args, **kwargs):
        if current_user() is None:
            session.clear()
            return redirect(url_for("login"))
        return view(*args, **kwargs)
    return wrapper


@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "GET":
        if current_user() is not None:
            return redirect(url_for("index"))
        return render_template("login.html")

    username = request.form.get("username", "").strip()
    password = request.form.get("password", "")

    if not username or not password:
        return render_template("login.html", error="Podaj nazwę użytkownika i hasło.", username=username)

    try:
        catalog = fetch_report_catalog(username, password)
    except UnexpectedReponse as UER:
        return render_template(
            "login.html",
            username=username,
            error=f"Nie udało się zalogować - wykryto {decode_response(UER.status_code)} (kod {UER.status_code}). "
                  f"Upewnij się czy podajesz poprawne dane logowania oraz czy łączysz się przez korporacyjną sieć SD6/VPN."
        )
    except Exception as E:
        print(E)
        return render_template(
            "login.html",
            username=username,
            error="Nie udało się pobrać listy źródeł danych z raportu konfiguracyjnego. "
                  "Sprawdź połączenie z siecią SD6/VPN."
        )

    if not catalog:
        return render_template(
            "login.html",
            username=username,
            error="Raport konfiguracyjny nie zwrócił żadnych źródeł danych."
        )

    sid = secrets.token_urlsafe(32)
    with _STORE_LOCK:
        _USER_STORE[sid] = {
            "username": username,
            "password": password,
            "catalog": catalog,
            "latest_df": None,
            "last_seen": datetime.now(),
        }
    session.clear()
    session["sid"] = sid

    return redirect(url_for("index"))


@app.route("/logout")
def logout():
    sid = session.pop("sid", None)
    if sid:
        with _STORE_LOCK:
            _USER_STORE.pop(sid, None)
    return redirect(url_for("login"))


@app.route("/")
@login_required
def index():
    user = current_user()
    return render_template(
        "index.html",
        environments=user["catalog"],
        username=user["username"],
    )

@app.route("/generate", methods=["POST"])
@login_required
def generate():

    user = current_user()

    env = request.form["env"]

    # Ścieżkę raportu bierzemy z pobranej przy logowaniu konfiguracji, nie z formularza
    entry = next((e for e in user["catalog"] if e["env_name"] == env), None)
    if entry is None:
        return redirect(url_for("index"))

    date_from = request.form["date_from"]
    date_to = request.form["date_to"]

    selected_sections = SECTIONS

    try:
        xml_text = run_report(
            entry["env_name"],
            entry["report_path"],
            user["username"],
            user["password"],
            date_from,
            date_to
        )

        df = process_xml(
            xml_text,
            selected_sections
        )

        user["latest_df"] = df

        html_table = df.to_html(
            classes="table table-striped",
            index=False
        )

        return render_template(
            "results.html",
            table=html_table,
            rows=len(df)
        )
    
    except UnexpectedReponse as UER:
        return render_template(
            "unexpected-response.html",
            response_code=UER.status_code,
            response_description=decode_response(UER.status_code)
        )

@app.route("/download")
@login_required
def download():

    latest_df = current_user()["latest_df"]
    if latest_df is None:
        return redirect(url_for("index"))

    csv_buffer = io.StringIO()

    latest_df.to_csv(
        csv_buffer,
        sep=",",
        index=False
    )

    mem = io.BytesIO()
    mem.write(csv_buffer.getvalue().encode("utf-8"))
    mem.seek(0)

    ds_str = str(datetime.now()).split(' ')
    current_timestamp = f"{ds_str[0].replace('-', '')}_{ds_str[1].split('.')[0].replace(':', '')}"


    return send_file(
        mem,
        as_attachment=True,
        download_name=f"HRConnect_{current_timestamp}.csv",
        mimetype="text/csv"
    )

if __name__ == "__main__":
    app.run(debug=False)
