PROXY = "http://proxy-app.hut.chem.corp.local:3128"
PROXIES = {
    "http": PROXY,
    "https": PROXY  # Assuming the same proxy is used for HTTPS
}
# PROXIES = {} 
# odkomentować linię 6, 
# jeśli hostujemy się z tym na autoryzowanym przez dane środowisko HRC serwerze, ale poza naszą siecią SD6/VPN

ENDPOINTS = {
    "prod": "https://fa-eocc-saasfaprod1.fa.ocs.oraclecloud.com/xmlpserver/services/v2/ReportService",
    "dev1": "https://fa-eocc-dev1-saasfaprod1.fa.ocs.oraclecloud.com/xmlpserver/services/v2/ReportService"
}

# Raport konfiguracyjny BIP zwracający listę źródeł danych (kolumny NAME, ENV_NAME, REPORT_PATH).
# Zastępuje dawny słownik REPORT_PATHS.
CONFIG_REPORT_PATH = '/Custom/Hutchinson Reports/Local Admin Reports/Payroll Connectivity Poland/Configuration ALL-ENV.xdo'

# Klucz z ENDPOINTS - środowisko, na którym leży raport konfiguracyjny
# i na którym weryfikujemy dane logowania przy wejściu do aplikacji.
CONFIG_ENV = "prod"

# Po ilu minutach bezczynności sesja użytkownika (a z nią zapamiętane hasło) wygasa.
SESSION_IDLE_MINUTES = 60
